# ESP32 SH1106 Dracula Lyrics Visualizer

Animated **lyrics visualizer** for **ESP32 + 7-pin SH1106 OLED (SPI)**.

Words from the song sync with **9 different animated backgrounds** and cool text effects.

---

## Features

### Backgrounds
- Bat Swarm
- Geometric Mandala
- Synthwave 3D
- Tunnel + EQ Bars
- Vortex
- Matrix Rain
- Oscilloscope Wave
- Lightning Bolts
- 3D Rotating Cube

### Text Effects
- Pop
- Bounce
- Shake
- Invert
- Glitch
- Zoom In
- Typewriter

- Auto scene switching based on lyrics timeline  
- Continuous loop  

---

## Hardware Required

| Item | Details |
|------|---------|
| Board | ESP32 Dev Module |
| Display | 7-pin SH1106 128×64 OLED (SPI) |

### Wiring

| OLED Pin | ESP32 GPIO |
|----------|------------|
| GND      | GND        |
| VCC      | 3.3V       |
| D0 (CLK) | **18**     |
| D1 (MOSI)| **23**     |
| RES      | **16**     |
| DC       | **17**     |
| CS       | **5**      |

---

## Libraries

Install these from **Arduino Library Manager**:

1. `Adafruit GFX Library`
2. `Adafruit SH110X`

---

## How to Upload

1. Open `DraculaVisualizer.ino` in Arduino IDE
2. **Tools → Board → ESP32 Dev Module**
3. Select correct **COM port**
4. Click **Upload**

---

## How it Works

- Lyrics are timed in milliseconds
- Each word triggers a background + text effect
- After the full timeline finishes, it automatically restarts

---

## Credits

Adapted for **SH1106 SPI OLED** on ESP32.

Feel free to fork, modify and share!
